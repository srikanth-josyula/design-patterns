package com.designpatterns.creational.abstract_factory.medivial_age;

import com.designpatterns.creational.abstract_factory.NavalUnit;

public class BoatUnit implements NavalUnit {

	@Override
	public void sendUnits() {
		System.out.println("Boat Units are being sent");
	}
}
