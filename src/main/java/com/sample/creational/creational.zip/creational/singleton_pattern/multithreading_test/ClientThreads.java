package com.designpatterns.creational.singleton_pattern.multithreading_test;

/**
 * If you run this code many times, you will see sometimes both the threads creates different instances.
 * @author SriKanth
 *
 */
public class ClientThreads {
	public static void main(String[] args) {
        //Thread 1
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                LazyRegistrywithThreading instance1 = LazyRegistrywithThreading.getInstance();
                System.out.println("Instance 1 :" + instance1.hashCode());
            }
        });

        //Thread 2
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
            	LazyRegistrywithThreading instance2 = LazyRegistrywithThreading.getInstance();
                System.out.println("Instance 2 :" + instance2.hashCode());
            }
        });

        //start both the threads
        t1.start();
        t2.start();
   }
	
}
