package com.designpatterns.creational.abstract_factory.insdustrial_age;

import com.designpatterns.creational.abstract_factory.LandUnit;

public class RifleMenUnit implements LandUnit {

	@Override
	public void deployUnits() {
		System.out.println("Rifle Trops are Deployed");
	}

	@Override
	public void withdrawUnits() {
		System.out.println("Rifle Trops are withdrawen");
	}


}
