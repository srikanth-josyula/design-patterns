package com.designpatterns.creational.abstract_factory.medivial_age;

import com.designpatterns.creational.abstract_factory.LandUnit;

public class SwordMenUnit implements LandUnit {

	@Override
	public void deployUnits() {
		System.out.println("Sword Trops are Deployed");
	}

	@Override
	public void withdrawUnits() {
		System.out.println("Sword Trops are withdrawen");
	}

}
