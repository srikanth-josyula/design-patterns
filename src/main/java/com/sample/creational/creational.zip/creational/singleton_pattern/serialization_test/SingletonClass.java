package com.designpatterns.creational.singleton_pattern.serialization_test;

public class SingletonClass {

	private SingletonClass() {

	}

	private static volatile SingletonClass INSTANCE;

	public static SingletonClass getInstance() {
		if (INSTANCE == null) {
			synchronized (SingletonClass.class) {
				if (INSTANCE == null) {
					INSTANCE = new SingletonClass();
				}
			}
		}
		return INSTANCE;
	}
}
