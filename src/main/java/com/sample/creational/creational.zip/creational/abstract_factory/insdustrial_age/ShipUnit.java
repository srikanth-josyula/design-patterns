package com.designpatterns.creational.abstract_factory.insdustrial_age;

import com.designpatterns.creational.abstract_factory.NavalUnit;

public class ShipUnit implements NavalUnit {

	@Override
	public void sendUnits() {
		System.out.println("Ship Units are being sent");
	}

}
