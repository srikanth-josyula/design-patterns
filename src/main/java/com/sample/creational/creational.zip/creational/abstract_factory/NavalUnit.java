package com.designpatterns.creational.abstract_factory;

public interface NavalUnit {

	public void sendUnits();

}
