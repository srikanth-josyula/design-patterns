package com.designpatterns.creational.singleton_pattern;

public class Client {

	public static void main(String[] args) {

		/*
		 * EagerRegistry reg1 = EagerRegistry.getInstance(); EagerRegistry reg2 =
		 * EagerRegistry.getInstance();
		 * 
		 * System.out.println(reg1.hashCode() == reg2.hashCode());
		 */

		LazyRegistryIODH singleton;

		singleton = LazyRegistryIODH.getInstance();
		LazyRegistryIODH singleton2 = LazyRegistryIODH.getInstance();
		System.out.println(singleton == singleton2);
	}

}
