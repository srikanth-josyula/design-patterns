package com.designpatterns.creational.abstract_factory.insdustrial_age;

import com.designpatterns.creational.abstract_factory.GameUnitFactory;
import com.designpatterns.creational.abstract_factory.LandUnit;
import com.designpatterns.creational.abstract_factory.NavalUnit;

public class IndustrialGameUnitFactory implements GameUnitFactory {

	@Override
	public LandUnit createLandUnit() {

		return new RifleMenUnit();
	}

	@Override
	public NavalUnit createNavalUnit() {

		return new ShipUnit();
	}

}
