package com.designpatterns.creational.abstract_factory;

public interface LandUnit {

	public void deployUnits();

	public void withdrawUnits();

}
