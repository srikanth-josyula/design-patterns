package com.designpatterns.creational.abstract_factory;

public interface GameUnitFactory {

	public LandUnit createLandUnit();

	public NavalUnit createNavalUnit();
}
