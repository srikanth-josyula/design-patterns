package com.designpatterns.creational.abstract_factory.medivial_age;

import com.designpatterns.creational.abstract_factory.GameUnitFactory;
import com.designpatterns.creational.abstract_factory.LandUnit;
import com.designpatterns.creational.abstract_factory.NavalUnit;

public class MedivialGameUnitFactory implements GameUnitFactory {

	@Override
	public LandUnit createLandUnit() {

		return new SwordMenUnit();
	}

	@Override
	public NavalUnit createNavalUnit() {

		return new BoatUnit();
	}
}
