package com.designpatterns.creational.abstract_factory;

import com.designpatterns.creational.abstract_factory.insdustrial_age.IndustrialGameUnitFactory;
import com.designpatterns.creational.abstract_factory.medivial_age.MedivialGameUnitFactory;

public class Client {

	private GameUnitFactory factory;

	public Client(GameUnitFactory factory) {
		this.factory = factory;
	}

	public void createUnit() {
		LandUnit landunit = factory.createLandUnit();
		landunit.deployUnits();
		NavalUnit navalunit = factory.createNavalUnit();
		navalunit.sendUnits();

	}

	public static void main(String[] args) {

		Client gameunit = new Client(new IndustrialGameUnitFactory());
		gameunit.createUnit();
		System.out.println("***************************************");
		Client gameunit1 = new Client(new MedivialGameUnitFactory());
		gameunit1.createUnit();

	}
}
