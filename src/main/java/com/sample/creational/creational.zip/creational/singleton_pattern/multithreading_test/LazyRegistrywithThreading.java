package com.designpatterns.creational.singleton_pattern.multithreading_test;

public class LazyRegistrywithThreading {

	private LazyRegistrywithThreading() {

	}

	//Use volatile to allow thread to get new value instead cached value
	
	private static volatile LazyRegistrywithThreading INSTANCE;

	public static LazyRegistrywithThreading getInstance() {
		
		// CASE 1 :: without sync block
		/*if (INSTANCE == null) {
			INSTANCE = new LazyRegistrywithThreading();
		}*/
		
		// CASE 2 :: without double check locking
	    /*if (INSTANCE == null) {
	    	synchronized (LazyRegistrywithThreading.class) {
	    		INSTANCE = new LazyRegistrywithThreading();	
			}
		}*/
	    
	    if (INSTANCE == null) {
	    	synchronized (LazyRegistrywithThreading.class) {
	    		if (INSTANCE == null) {
	    	    		INSTANCE = new LazyRegistrywithThreading();	
	    		}
	    	}
		}
		return INSTANCE;
	}
}
